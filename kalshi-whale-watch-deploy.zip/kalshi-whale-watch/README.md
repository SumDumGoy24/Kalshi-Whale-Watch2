# Kalshi Whale Watch

A read-only Android-friendly Progressive Web App (PWA) and FastAPI service for Kalshi public sports markets and large public executed trades.

## Features
- Scans up to five pages of open Kalshi markets (up to 1,000 rows) and classifies sports using market keywords plus Kalshi series category metadata.
- Reads the public global trade tape and estimates executed notional from contract count × taker outcome price; default whale threshold is $500.
- Refreshes automatically while the app is open; threshold and refresh preferences are saved on the device.
- Parlay Lab calculates an illustrative independent-leg probability and expected value from user-entered probabilities, actual combo quote, and fee. It explicitly warns about correlated legs.
- Installable PWA on Android Chrome when served over HTTPS.

## Deploy to Render
1. Create a GitHub repository and upload this folder's contents.
2. In Render, choose **New → Blueprint** and select the repository containing `render.yaml`.
3. Deploy the `kalshi-whale-watch` web service.
4. Open the deployed `https://...onrender.com` URL and verify `/api/health` returns `{"status":"ok"...}`.
5. On Android Chrome, open the HTTPS URL → ⋮ → **Install app** (or **Add to Home screen**).

The service uses Kalshi's public, unauthenticated market-data endpoints. No Kalshi account credentials or private keys are required because this version does not place trades.

## Run locally
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
Then open http://localhost:8000.

## Tests
```bash
cd backend
pip install pytest
PYTHONPATH=. pytest -q
```

## Important limitations
- The scanner covers the open market pages it retrieves; keyword classification and API pagination mean coverage is not guaranteed exhaustive. Increase page depth or add Kalshi series allowlists for full coverage.
- The trade tape is a sample of public executions. The app does not infer identities, beneficial ownership, or intent. The $ value is estimated and is not a verified account-level bet size.
- No AI picks are fabricated. The parlay calculator uses probabilities supplied by the user and assumes independence unless flagged; flagged correlated legs still require a joint probability model. Use a real Kalshi combo quote and include actual fees.
- Browser notifications in this release are generated while the app is open. True background push notifications require a push provider, VAPID keys, server subscription storage, and an HTTPS deployment; these are not configured in this starter.
- This package is a PWA, not a signed native APK. It installs on Android as an app from Chrome after HTTPS deployment. Native APK packaging can be added after a stable production domain exists.
