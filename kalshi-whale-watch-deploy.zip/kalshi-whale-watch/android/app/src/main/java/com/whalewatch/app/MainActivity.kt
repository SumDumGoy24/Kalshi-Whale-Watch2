package com.whalewatch.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101923)
private val Panel = Color(0xFF1D2D3B)
private val Mint = Color(0xFF35D49A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WhaleWatchApp() }
    }
}

@Composable
fun WhaleWatchApp() {
    var selected by remember { mutableStateOf(0) }
    var threshold by remember { mutableFloatStateOf(500f) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Navy, surface = Panel)) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Parlays", "Whales", "Markets", "Settings").forEachIndexed { i, label ->
                    NavigationBarItem(selected = selected == i, onClick = { selected = i },
                        icon = { Icon(listOf(Icons.Default.Dashboard, Icons.Default.EmojiEvents, Icons.Default.Water, Icons.Default.ShowChart, Icons.Default.Settings)[i], contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp) })
                }
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("KALSHI WHALE WATCH", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
                            Text("SPORTS INTELLIGENCE CENTER", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        }
                        Icon(Icons.Default.Radar, null, tint = Mint, modifier = Modifier.size(32.dp))
                    }
                }
                item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetricCard("SPORTS MARKETS", "ALL", "Live scanner", Modifier.weight(1f))
                    MetricCard("WHALE ALERT", "$${threshold.toInt()}", "Minimum trade", Modifier.weight(1f))
                } }
                item { SectionCard("TOP PARLAY OPPORTUNITIES", "Live probability models and combo quotes will appear here after the backend is connected.") }
                item { SectionCard("LATEST WHALE ACTIVITY", "Large public trades will be ranked here. No trader identities are inferred.") }
                item { SectionCard("MARKET MOVEMENTS", "Price changes, volume spikes and liquidity signals will appear here.") }
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
                        Text("ALERT SETTINGS", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Minimum public trade size", color = Color.LightGray, fontSize = 12.sp)
                        Slider(value = threshold, onValueChange = { threshold = it }, valueRange = 100f..10000f, steps = 98)
                        Text("$${threshold.toInt()} USD", color = Mint, fontWeight = FontWeight.Bold)
                    }
                }
                item { Text("Prototype UI • Not connected to live data yet", color = Color.Gray, fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(title, color = Color.LightGray, fontSize = 10.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Black, fontSize = 25.sp)
        Text(subtitle, color = Mint, fontSize = 11.sp)
    }
}

@Composable
private fun SectionCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(body, color = Color.LightGray, fontSize = 12.sp, lineHeight = 18.sp)
    }
}
