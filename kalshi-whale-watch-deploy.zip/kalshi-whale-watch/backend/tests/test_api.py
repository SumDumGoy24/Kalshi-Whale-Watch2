from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get('/api/health')
    assert r.status_code == 200
    assert r.json()['status'] == 'ok'

def test_frontend_served():
    r = client.get('/')
    assert r.status_code == 200
    assert 'Kalshi Whale Watch' in r.text

def test_parlay_endpoint():
    r = client.post('/api/analysis/parlay', json={
        'legs': [{'label':'A','probability':0.5},{'label':'B','probability':0.5}],
        'offered_price':0.2,'fee':0.0,'correlated':False
    })
    assert r.status_code == 200
    assert r.json()['estimated_probability'] == 0.25
