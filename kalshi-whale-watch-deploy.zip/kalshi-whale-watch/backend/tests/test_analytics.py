from app.analytics import classify_sport, estimate_trade_cost, normalize_trade, parlay_estimate

def test_sport_classification():
    assert classify_sport({"title":"NFL: Team A vs Team B"}) == "NFL"
    assert classify_sport({"title":"ATP tennis final"}) == "Tennis"

def test_trade_notional_yes_cents():
    assert estimate_trade_cost({"count":1000,"yes_price":60,"taker_side":"yes"}) == 600

def test_trade_notional_fixed_point_no():
    assert estimate_trade_cost({"count_fp":"1000.00","no_price_dollars":"0.4000","taker_outcome_side":"no"}) == 400

def test_threshold_filters():
    assert normalize_trade({"count":10,"yes_price":20}, 500) is None
    assert normalize_trade({"count":1000,"yes_price":60}, 500)["estimated_notional_usd"] == 600

def test_parlay_estimate():
    out = parlay_estimate([{"label":"A","probability":.5},{"label":"B","probability":.5}], .2)
    assert out["estimated_probability"] == .25
    assert out["expected_value_per_contract"] == .05
