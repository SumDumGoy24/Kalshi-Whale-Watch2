"""Public, read-only Kalshi Trade API v2 client."""
from __future__ import annotations
import os
from typing import Any
import httpx

BASE_URL = os.getenv("KALSHI_BASE_URL", "https://external-api.kalshi.com/trade-api/v2")

class KalshiClient:
    def __init__(self, base_url: str = BASE_URL):
        self.base_url = base_url.rstrip("/")

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=25.0, headers={"User-Agent": "KalshiWhaleWatch/1.0"}) as session:
            response = await session.get(f"{self.base_url}{path}", params=params)
            response.raise_for_status()
            return response.json()

    async def markets(self, limit: int = 200, cursor: str | None = None) -> dict[str, Any]:
        p: dict[str, Any] = {"status": "open", "limit": min(limit, 200)}
        if cursor: p["cursor"] = cursor
        return await self._get("/markets", p)

    async def events(self, limit: int = 200, cursor: str | None = None) -> dict[str, Any]:
        p: dict[str, Any] = {"status": "open", "with_nested_markets": "true", "limit": min(limit, 200)}
        if cursor: p["cursor"] = cursor
        return await self._get("/events", p)

    async def series(self) -> dict[str, Any]:
        return await self._get("/series", {"include_product_metadata": "true"})

    async def trades(self, ticker: str | None = None, limit: int = 200, cursor: str | None = None) -> dict[str, Any]:
        p: dict[str, Any] = {"limit": min(limit, 1000)}
        if ticker: p["ticker"] = ticker
        if cursor: p["cursor"] = cursor
        return await self._get("/markets/trades", p)

    async def orderbook(self, ticker: str) -> dict[str, Any]:
        return await self._get(f"/markets/{ticker}/orderbook")
