from __future__ import annotations
from typing import Any

SPORT_TERMS = {
    "NFL": ("nfl", "national football league", "super bowl", "football"),
    "NBA": ("nba", "basketball", "wnba"),
    "MLB": ("mlb", "baseball", "world series"),
    "NHL": ("nhl", "hockey", "stanley cup"),
    "Soccer": ("soccer", "premier league", "champions league", "mls", "la liga", "serie a", "bundesliga", "liga mx", "fifa"),
    "Tennis": ("tennis", "atp", "wta", "grand slam", "wimbledon", "us open"),
    "College sports": ("ncaa", "college football", "college basketball", "march madness"),
    "Golf": ("golf", "pga", "lpga", "masters tournament"),
    "MMA / Boxing": ("ufc", "mma", "boxing", "bellator"),
    "Motorsports": ("nascar", "formula 1", "formula one", "f1", "indycar", "motogp"),
    "Cricket": ("cricket", "ipl", "test match"),
    "Rugby": ("rugby", "six nations"),
    "Esports": ("esports", "league of legends", "counter-strike", "valorant", "dota"),
}

def classify_sport(item: dict[str, Any], series_map: dict[str, str] | None = None) -> str:
    series_ticker = str(item.get("series_ticker", ""))
    series_category = (series_map or {}).get(series_ticker, "")
    text = " ".join(str(item.get(k, "")) for k in ("title", "subtitle", "sub_title", "category", "event_ticker", "ticker", "series_ticker", "sport")) + " " + series_category
    low = text.lower()
    # Series category is the strongest signal when Kalshi supplies it.
    if "sport" in series_category.lower():
        for sport, terms in SPORT_TERMS.items():
            if any(term in low for term in terms): return sport
        return "Other sports"
    for sport, terms in SPORT_TERMS.items():
        if any(term in low for term in terms): return sport
    return "Other / review"

def estimate_trade_cost(trade: dict[str, Any]) -> float:
    count_raw = trade.get("count_fp", trade.get("count", trade.get("contracts", 0)))
    count = float(count_raw or 0)
    side = str(trade.get("taker_outcome_side", trade.get("taker_side", "yes"))).lower()
    price = trade.get("yes_price_dollars") if side != "no" else trade.get("no_price_dollars")
    if price is None:
        price = trade.get("yes_price") if side != "no" else trade.get("no_price")
    if price is None: price = trade.get("price", 0)
    price = float(price or 0)
    dollars = price / 100 if price > 1 else price
    return round(count * dollars, 2)

def normalize_trade(trade: dict[str, Any], threshold: float) -> dict[str, Any] | None:
    value = estimate_trade_cost(trade)
    if value < threshold: return None
    side = str(trade.get("taker_outcome_side", trade.get("taker_side", "unknown"))).upper()
    return {
        "ticker": trade.get("ticker", ""), "trade_id": trade.get("trade_id") or trade.get("id"),
        "contracts": float(trade.get("count_fp", trade.get("count", trade.get("contracts", 0))) or 0),
        "outcome_side": side, "book_side": trade.get("taker_book_side", "unknown"),
        "price_dollars": float((trade.get("yes_price_dollars") if side != "NO" else trade.get("no_price_dollars")) or 0) if (trade.get("yes_price_dollars") is not None or trade.get("no_price_dollars") is not None) else (float((trade.get("yes_price") if side != "NO" else trade.get("no_price")) or 0) / 100),
        "estimated_notional_usd": value,
        "created_time": trade.get("created_time", trade.get("created_at", trade.get("timestamp"))),
        "is_block_trade": bool(trade.get("is_block_trade", False)),
        "note": "Estimated executed contract notional; not a trader identity or proof of informed activity."
    }

def parlay_estimate(legs: list[dict[str, Any]], offered_price: float, fee: float = 0.0, correlated: bool = False) -> dict[str, Any]:
    if not legs: raise ValueError("Add at least one leg")
    probs = [float(x["probability"]) for x in legs]
    if any(p < 0 or p > 1 for p in probs): raise ValueError("Each probability must be between 0 and 1")
    if not 0 < offered_price < 1: raise ValueError("Combo quote must be between $0 and $1")
    if fee < 0: raise ValueError("Fee cannot be negative")
    joint = 1.0
    for p in probs: joint *= p
    cost = offered_price + fee
    ev = joint - cost
    return {"estimated_probability": round(joint, 6), "estimated_fair_price": round(joint, 4), "offered_price": round(offered_price, 4), "fee_estimate": round(fee, 4), "expected_value_per_contract": round(ev, 4), "expected_return_on_cost": round(ev / cost, 4), "independence_assumption": not correlated, "warning": "This is a screening estimate only. Enter calibrated probabilities and a live executable Kalshi combo quote. Correlated legs require a joint model; this calculator does not correct correlation." if not correlated else "Correlated legs were flagged. This calculator still multiplies probabilities and is NOT valid for pricing the combo. Supply a defensible joint probability model before relying on the result."}
