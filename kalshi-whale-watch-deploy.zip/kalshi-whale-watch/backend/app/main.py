from __future__ import annotations
from pathlib import Path
import time
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from .kalshi import KalshiClient
from .analytics import classify_sport, normalize_trade, parlay_estimate

app = FastAPI(title="Kalshi Whale Watch", version="1.0.0", description="Read-only Kalshi sports market scanner and trade tape monitor")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
client = KalshiClient()
_sports_ticker_cache: dict[str, str] = {}
_sports_ticker_cache_at = 0.0

class Leg(BaseModel):
    label: str
    probability: float = Field(ge=0, le=1)
class ParlayRequest(BaseModel):
    legs: list[Leg]
    offered_price: float = Field(gt=0, lt=1)
    fee: float = Field(default=0, ge=0)
    correlated: bool = False

@app.get("/api/health")
async def health(): return {"status":"ok", "service":"kalshi-whale-watch", "version":"1.0.0"}

async def get_series_map():
    try:
        data = await client.series()
        return {str(s.get("ticker", "")): str(s.get("category", "")) for s in data.get("series", [])}
    except Exception:
        return {}

async def get_sports_tickers(force: bool = False) -> dict[str, str]:
    global _sports_ticker_cache, _sports_ticker_cache_at
    if _sports_ticker_cache and not force and time.time() - _sports_ticker_cache_at < 300:
        return _sports_ticker_cache
    series_map = await get_series_map()
    cursor = None; found: dict[str, str] = {}
    for _ in range(5):
        page = await client.markets(limit=200, cursor=cursor)
        for market in page.get("markets", []) or []:
            sport_name = classify_sport(market, series_map)
            if sport_name != "Other / review":
                found[str(market.get("ticker", ""))] = sport_name
        cursor = page.get("cursor")
        if not cursor: break
    _sports_ticker_cache = found; _sports_ticker_cache_at = time.time()
    return found

@app.get("/api/sports/markets")
async def sports_markets(limit: int = Query(default=200, ge=1, le=1000), pages: int = Query(default=3, ge=1, le=5), sport: str | None = None):
    try:
        series_map = await get_series_map()
        cursor = None; selected = []; scanned = 0; last_cursor = None
        for _ in range(pages):
            payload = await client.markets(limit=min(200, limit), cursor=cursor)
            rows = payload.get("markets", []) or []; scanned += len(rows)
            for m in rows:
                category = classify_sport(m, series_map)
                if category != "Other / review" and (not sport or sport.lower() == "all" or category.lower() == sport.lower()):
                    selected.append({**m, "sport": category})
            cursor = payload.get("cursor")
            last_cursor = cursor
            if not cursor or len(selected) >= limit: break
        selected.sort(key=lambda x: (x.get("close_time") or "9999", -(float(x.get("volume_fp", x.get("volume", 0)) or 0))))
        return {"count":len(selected[:limit]), "scanned":scanned, "markets":selected[:limit], "next_cursor":last_cursor, "source":"Kalshi public market API", "coverage":"Open market pages scanned and sports classified using series category plus market/event keywords. Increase pages for broader coverage; this is not a guaranteed exhaustive catalog."}
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Kalshi markets request failed: {exc}")

@app.get("/api/sports/events")
async def sports_events(limit: int = Query(default=200, ge=1, le=200)):
    try:
        data = await client.events(limit=limit)
        events = data.get("events", []) or []
        return {"count":len(events), "events":[{**e, "sport":classify_sport(e)} for e in events], "source":"Kalshi public API"}
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Kalshi events request failed: {exc}")

@app.get("/api/whales")
async def whales(threshold: float = Query(default=500, ge=1), limit: int = Query(default=500, ge=1, le=1000), ticker: str | None = None):
    try:
        sports_tickers = await get_sports_tickers()
        if ticker and ticker not in sports_tickers:
            raise HTTPException(status_code=404, detail="Ticker is not in the current open sports-market scan")
        payload = await client.trades(ticker=ticker, limit=limit)
        raw = payload.get("trades", []) or []
        trades = []
        for trade in raw:
            trade_ticker = str(trade.get("ticker", ticker or ""))
            if trade_ticker not in sports_tickers: continue
            normalized = normalize_trade(trade, threshold)
            if normalized is not None:
                normalized["sport"] = sports_tickers[trade_ticker]
                trades.append(normalized)
        trades.sort(key=lambda x: x["estimated_notional_usd"], reverse=True)
        return {"count":len(trades), "trades":trades, "threshold_usd":threshold, "source":"Kalshi public executed trade tape filtered to scanned open sports markets", "cursor":payload.get("cursor"), "sample_size":len(raw), "sports_markets_scanned":len(sports_tickers), "caveat":"Only the latest returned public trades are sampled, then filtered to currently open sports tickers discovered in the market scan. Older trades or closed markets may not appear. Large trade activity does not identify beneficial owners or prove informed betting. Notional is an estimate from contracts multiplied by the taker's outcome price."}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Kalshi trades request failed: {exc}")

@app.get("/api/markets/{ticker}/orderbook")
async def orderbook(ticker: str):
    try: return await client.orderbook(ticker)
    except Exception as exc: raise HTTPException(status_code=502, detail=f"Kalshi orderbook request failed: {exc}")

@app.post("/api/analysis/parlay")
async def analyze_parlay(req: ParlayRequest):
    try: return parlay_estimate([x.model_dump() for x in req.legs], req.offered_price, req.fee, req.correlated)
    except ValueError as exc: raise HTTPException(status_code=400, detail=str(exc))

FRONTEND = Path(__file__).resolve().parents[2] / "frontend"
if FRONTEND.exists(): app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
