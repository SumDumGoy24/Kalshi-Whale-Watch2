# Backend prototype

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000/docs` for the API explorer.

## Endpoints
- `GET /health`
- `GET /sports/markets?limit=200`
- `GET /sports/events?limit=200`
- `GET /whales/{market_ticker}?threshold=500&limit=100`
- `GET /markets/{market_ticker}/orderbook`
- `POST /analysis/parlay`

## Prototype limitations
- Sport detection is keyword-based and needs a maintained series/event taxonomy plus pagination to guarantee broad coverage.
- Whale endpoint currently inspects trades for one market ticker at a time. A production worker must discover active sports tickers, poll/subscribe to each, deduplicate trade IDs, persist history, and alert on threshold crossings.
- Notional is estimated from contract count and price. It is not proof of account identity or trader intent.
- Parlay calculator uses independent probabilities only. Production ranking needs calibrated probability models, correlation/joint outcome modeling, fees, RFQ quotes, liquidity, and backtesting.
- Public endpoints and response schemas should be verified against the current Kalshi API documentation before production deployment.
